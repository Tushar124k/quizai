import 'package:dio/dio.dart';
import '../models/models.dart';
import '../core/constants/app_constants.dart';

/// Routes MCQ to the correct AI provider and parses the structured response.
class AiService {
  final Dio _dio;

  AiService() : _dio = Dio(BaseOptions(
    connectTimeout: const Duration(milliseconds: AppConstants.aiTimeoutMs),
    receiveTimeout: const Duration(milliseconds: AppConstants.aiTimeoutMs),
    headers: {'Content-Type': 'application/json'},
  ));

  // ── Public API ─────────────────────────────────────────────────────────────

  Future<AiAnswer?> solve({
    required McqQuestion question,
    required AiProvider  provider,
    required String      apiKey,
  }) async {
    final prompt = _buildPrompt(question);
    try {
      final rawResponse = await switch (provider) {
        AiProvider.openai  => _callOpenAI(prompt, apiKey),
        AiProvider.gemini  => _callGemini(prompt, apiKey),
        AiProvider.claude  => _callClaude(prompt, apiKey),
        AiProvider.offline => null,
      };
      if (rawResponse == null) return null;
      return _parseResponse(rawResponse, provider);
    } on DioException catch (e) {
      throw AiException(_dioErrorMessage(e));
    }
  }

  void dispose() => _dio.close();

  // ── Prompt builder ─────────────────────────────────────────────────────────

  String _buildPrompt(McqQuestion q) {
    final buf = StringBuffer();
    buf.writeln('Question: ${q.questionText}');
    if (q.optionA != null) buf.writeln('A) ${q.optionA}');
    if (q.optionB != null) buf.writeln('B) ${q.optionB}');
    if (q.optionC != null) buf.writeln('C) ${q.optionC}');
    if (q.optionD != null) buf.writeln('D) ${q.optionD}');
    return buf.toString();
  }

  // ── OpenAI ─────────────────────────────────────────────────────────────────

  Future<String> _callOpenAI(String prompt, String apiKey) async {
    final response = await _dio.post(
      '${AppConstants.openAiBaseUrl}/chat/completions',
      options: Options(headers: {'Authorization': 'Bearer $apiKey'}),
      data: {
        'model': 'gpt-4o-mini',
        'max_tokens': 150,
        'temperature': 0.1,
        'messages': [
          {'role': 'system', 'content': AppConstants.aiSystemPrompt},
          {'role': 'user',   'content': prompt},
        ],
      },
    );
    return response.data['choices'][0]['message']['content'] as String;
  }

  // ── Gemini ─────────────────────────────────────────────────────────────────

  Future<String> _callGemini(String prompt, String apiKey) async {
    final response = await _dio.post(
      '${AppConstants.geminiBaseUrl}/models/gemini-2.0-flash:generateContent?key=$apiKey',
      data: {
        'contents': [
          {
            'parts': [
              {'text': '${AppConstants.aiSystemPrompt}\n\n$prompt'},
            ],
          }
        ],
        'generationConfig': {
          'temperature': 0.1,
          'maxOutputTokens': 150,
        },
      },
    );
    return response.data['candidates'][0]['content']['parts'][0]['text'] as String;
  }

  // ── Claude ─────────────────────────────────────────────────────────────────

  Future<String> _callClaude(String prompt, String apiKey) async {
    final response = await _dio.post(
      '${AppConstants.claudeBaseUrl}/messages',
      options: Options(headers: {
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      }),
      data: {
        'model': 'claude-haiku-4-5-20251001',
        'max_tokens': 150,
        'system': AppConstants.aiSystemPrompt,
        'messages': [
          {'role': 'user', 'content': prompt},
        ],
      },
    );
    return response.data['content'][0]['text'] as String;
  }

  // ── Response parser ────────────────────────────────────────────────────────

  AiAnswer? _parseResponse(String raw, AiProvider provider) {
    final answerRe     = RegExp(r'Answer:\s*([A-Da-d])', caseSensitive: false);
    final confidenceRe = RegExp(r'Confidence:\s*(\d+(?:\.\d+)?)%?');
    final explanRe     = RegExp(r'Explanation:\s*(.+)', dotAll: true);

    final ansMatch  = answerRe.firstMatch(raw);
    final confMatch = confidenceRe.firstMatch(raw);
    final explMatch = explanRe.firstMatch(raw);

    if (ansMatch == null) return null;

    final answer     = ansMatch.group(1)!.toUpperCase();
    final confidence = confMatch != null
        ? double.tryParse(confMatch.group(1)!) ?? 0.85
        : 0.85;
    final explanation = explMatch?.group(1)?.trim();

    return AiAnswer(
      answer:      answer,
      confidence:  (confidence > 1.0 ? confidence / 100 : confidence)
                       .clamp(0.0, 1.0),
      explanation: explanation,
      source:      provider,
    );
  }

  String _dioErrorMessage(DioException e) => switch (e.type) {
    DioExceptionType.connectionTimeout ||
    DioExceptionType.receiveTimeout    => 'Request timed out',
    DioExceptionType.connectionError   => 'No internet connection',
    _                                  =>
        e.response?.statusCode == 401  ? 'Invalid API key'
      : e.response?.statusCode == 429  ? 'Rate limit exceeded'
      : 'AI request failed (${e.response?.statusCode ?? 'unknown'})',
  };
}

class AiException implements Exception {
  final String message;
  const AiException(this.message);
  @override
  String toString() => message;
}
