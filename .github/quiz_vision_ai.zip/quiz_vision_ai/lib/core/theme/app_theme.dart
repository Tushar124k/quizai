import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // ── Palette ──────────────────────────────────────────────────────────────
  static const Color background    = Color(0xFF0A0C10);
  static const Color surface       = Color(0xFF12151C);
  static const Color surfaceGlass  = Color(0x1AFFFFFF);
  static const Color surfaceBorder = Color(0x26FFFFFF);
  static const Color accent        = Color(0xFF00E5B4);   // teal-mint
  static const Color accentWarm    = Color(0xFFFF6B35);   // amber-orange
  static const Color correct       = Color(0xFF1AE86D);   // success green
  static const Color wrong         = Color(0xFFFF3D5A);   // error red
  static const Color warning       = Color(0xFFFFD166);   // caution yellow
  static const Color textPrimary   = Color(0xFFF0F4FF);
  static const Color textSecondary = Color(0xFF8A93A8);
  static const Color textMuted     = Color(0xFF404757);

  // ── Typography ────────────────────────────────────────────────────────────
  static TextTheme _buildTextTheme() {
    return TextTheme(
      displayLarge: GoogleFonts.spaceGrotesk(
        fontSize: 32, fontWeight: FontWeight.w700, color: textPrimary,
        letterSpacing: -0.5,
      ),
      displayMedium: GoogleFonts.spaceGrotesk(
        fontSize: 24, fontWeight: FontWeight.w700, color: textPrimary,
      ),
      headlineMedium: GoogleFonts.spaceGrotesk(
        fontSize: 20, fontWeight: FontWeight.w600, color: textPrimary,
      ),
      titleLarge: GoogleFonts.spaceGrotesk(
        fontSize: 17, fontWeight: FontWeight.w600, color: textPrimary,
      ),
      titleMedium: GoogleFonts.inter(
        fontSize: 15, fontWeight: FontWeight.w600, color: textPrimary,
      ),
      bodyLarge: GoogleFonts.inter(
        fontSize: 15, fontWeight: FontWeight.w400, color: textPrimary,
        height: 1.55,
      ),
      bodyMedium: GoogleFonts.inter(
        fontSize: 13, fontWeight: FontWeight.w400, color: textSecondary,
        height: 1.5,
      ),
      labelLarge: GoogleFonts.spaceGrotesk(
        fontSize: 13, fontWeight: FontWeight.w600, color: textPrimary,
        letterSpacing: 0.3,
      ),
      labelSmall: GoogleFonts.jetBrainsMono(
        fontSize: 10, fontWeight: FontWeight.w500, color: textSecondary,
        letterSpacing: 1.2,
      ),
    );
  }

  static ThemeData get dark => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: background,
    colorScheme: const ColorScheme.dark(
      primary: accent,
      secondary: accentWarm,
      surface: surface,
      onPrimary: background,
      onSecondary: background,
      onSurface: textPrimary,
      error: wrong,
    ),
    textTheme: _buildTextTheme(),
    iconTheme: const IconThemeData(color: textSecondary, size: 20),
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: GoogleFonts.spaceGrotesk(
        fontSize: 18, fontWeight: FontWeight.w700, color: textPrimary,
      ),
      iconTheme: const IconThemeData(color: textPrimary),
    ),
    cardTheme: CardTheme(
      color: surface,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: surfaceBorder, width: 1),
      ),
    ),
    dividerTheme: const DividerThemeData(
      color: surfaceBorder, thickness: 1,
    ),
  );
}

// ── Glassmorphism decoration helper ──────────────────────────────────────────
BoxDecoration glassDecoration({
  double radius = 16,
  Color? borderColor,
  Color? bgColor,
}) => BoxDecoration(
  color: bgColor ?? AppTheme.surfaceGlass,
  borderRadius: BorderRadius.circular(radius),
  border: Border.all(
    color: borderColor ?? AppTheme.surfaceBorder,
    width: 1,
  ),
);
