class AppConstants {
  // API
  static const String openAiBaseUrl     = 'https://api.openai.com/v1';
  static const String geminiBaseUrl     = 'https://generativelanguage.googleapis.com/v1beta';
  static const String claudeBaseUrl     = 'https://api.anthropic.com/v1';

  // Scan loop
  static const int    scanIntervalMs    = 300;
  static const int    ocrTimeoutMs      = 1500;
  static const int    aiTimeoutMs       = 8000;
  static const double minTextConfidence = 0.65;

  // OCR patterns
  static const String questionPattern =
      r'(\d+[\.\)]\s*.{10,})';
  static const String optionPattern =
      r'(?:^|\n)\s*([A-Da-d][\.\):])\s*(.+)';

  // Storage
  static const String dbName           = 'quiz_history.db';
  static const int    dbVersion        = 2;
  static const String historyTable     = 'quiz_history';
  static const String offlineQBank     = 'question_bank';

  // Prefs keys
  static const String kAiProvider      = 'ai_provider';
  static const String kApiKey          = 'api_key_';
  static const String kSpeakAnswer     = 'speak_answer';
  static const String kAutoScan        = 'auto_scan';
  static const String kOfflineFirst    = 'offline_first';
  static const String kFlashEnabled    = 'flash_enabled';

  // AI prompt
  static const String aiSystemPrompt = '''
You are an expert quiz assistant specialized in MCQ examinations.
Analyze the question carefully, apply domain knowledge, and respond with:
Answer: [single letter A/B/C/D]
Confidence: [percentage]%
Explanation: [1-2 sentence explanation]

Never add extra text. Only output the three lines above.
''';
}
