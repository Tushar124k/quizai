import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme/app_theme.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  final Map<AiProvider, TextEditingController> _keyControllers = {};
  final Map<AiProvider, bool> _obscured = {};

  @override
  void initState() {
    super.initState();
    for (final p in AiProvider.values) {
      _keyControllers[p] = TextEditingController();
      _obscured[p] = true;
    }
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadKeys());
  }

  Future<void> _loadKeys() async {
    final svc = ref.read(settingsServiceProvider);
    for (final p in AiProvider.values) {
      final key = await svc.getApiKey(p);
      if (key != null && mounted) {
        setState(() => _keyControllers[p]!.text = key);
      }
    }
  }

  @override
  void dispose() {
    for (final c in _keyControllers.values) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settingsAsync = ref.watch(settingsProvider);

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Settings')),
      body: settingsAsync.when(
        loading: () => const Center(
          child: CircularProgressIndicator(color: AppTheme.accent)),
        error: (e, _) => Center(child: Text('Error: $e')),
        data: (settings) => ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          children: [
            // ── AI Provider ──────────────────────────────────────────
            _SectionHeader('AI PROVIDER'),
            _ProviderSelector(
              current:  settings.aiProvider,
              onChange: (p) => ref.read(settingsProvider.notifier)
                  .update(settings.copyWith(aiProvider: p)),
            ),

            const SizedBox(height: 20),
            _SectionHeader('API KEYS'),
            _ApiKeyNote(),

            for (final provider in [
              AiProvider.openai,
              AiProvider.gemini,
              AiProvider.claude,
            ]) ...[
              const SizedBox(height: 12),
              _ApiKeyField(
                provider:   provider,
                controller: _keyControllers[provider]!,
                obscured:   _obscured[provider]!,
                isActive:   settings.aiProvider == provider,
                onToggleObscure: () =>
                    setState(() => _obscured[provider] = !_obscured[provider]!),
                onSave: (key) => ref.read(settingsProvider.notifier)
                    .setApiKey(provider, key),
              ),
            ],

            const SizedBox(height: 24),
            _SectionHeader('BEHAVIOR'),
            _ToggleSetting(
              label:       'Auto-scan',
              subtitle:    'Continuously scan for new questions',
              icon:        Icons.radar_rounded,
              value:       settings.autoScan,
              onChanged:   (v) => ref.read(settingsProvider.notifier)
                  .update(settings.copyWith(autoScan: v)),
            ),
            _ToggleSetting(
              label:       'Speak answer',
              subtitle:    'Read answer aloud via TTS',
              icon:        Icons.volume_up_rounded,
              value:       settings.speakAnswer,
              onChanged:   (v) => ref.read(settingsProvider.notifier)
                  .update(settings.copyWith(speakAnswer: v)),
            ),
            _ToggleSetting(
              label:       'Offline first',
              subtitle:    'Search local bank before calling AI',
              icon:        Icons.offline_bolt_rounded,
              value:       settings.offlineFirst,
              onChanged:   (v) => ref.read(settingsProvider.notifier)
                  .update(settings.copyWith(offlineFirst: v)),
            ),

            const SizedBox(height: 24),
            _SectionHeader('ABOUT'),
            const _AboutCard(),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

// ── Section header ─────────────────────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  final String text;
  const _SectionHeader(this.text);

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(4, 4, 4, 8),
    child: Text(
      text,
      style: TextStyle(
        fontFamily: 'JetBrainsMono',
        fontSize:   10,
        letterSpacing: 1.5,
        color: AppTheme.textMuted,
        fontWeight: FontWeight.w700,
      ),
    ),
  );
}

// ── Provider selector ──────────────────────────────────────────────────────────

class _ProviderSelector extends StatelessWidget {
  final AiProvider current;
  final void Function(AiProvider) onChange;

  const _ProviderSelector({required this.current, required this.onChange});

  @override
  Widget build(BuildContext context) => Wrap(
    spacing: 10, runSpacing: 10,
    children: AiProvider.values.map((p) {
      final active = p == current;
      return GestureDetector(
        onTap: () => onChange(p),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color:        active
                ? AppTheme.accent.withOpacity(0.15)
                : AppTheme.surface,
            borderRadius: BorderRadius.circular(12),
            border:       Border.all(
              color: active
                  ? AppTheme.accent.withOpacity(0.6)
                  : AppTheme.surfaceBorder,
              width: active ? 1.5 : 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (active)
                Container(
                  width: 6, height: 6,
                  margin: const EdgeInsets.only(right: 8),
                  decoration: BoxDecoration(
                    color: AppTheme.accent,
                    shape: BoxShape.circle,
                  ),
                ),
              Text(
                p.displayName,
                style: TextStyle(
                  fontSize:   13,
                  fontWeight: active ? FontWeight.w600 : FontWeight.w400,
                  color: active ? AppTheme.accent : AppTheme.textSecondary,
                ),
              ),
            ],
          ),
        ),
      );
    }).toList(),
  );
}

// ── API key field ──────────────────────────────────────────────────────────────

class _ApiKeyNote extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(12),
    margin: const EdgeInsets.only(bottom: 4),
    decoration: BoxDecoration(
      color: AppTheme.accentWarm.withOpacity(0.07),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: AppTheme.accentWarm.withOpacity(0.2)),
    ),
    child: Row(
      children: [
        const Icon(Icons.lock_outline_rounded,
                   color: AppTheme.accentWarm, size: 16),
        const SizedBox(width: 8),
        const Expanded(
          child: Text(
            'API keys are stored locally on your device only.',
            style: TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 12,
            ),
          ),
        ),
      ],
    ),
  );
}

class _ApiKeyField extends StatelessWidget {
  final AiProvider  provider;
  final TextEditingController controller;
  final bool        obscured;
  final bool        isActive;
  final VoidCallback onToggleObscure;
  final void Function(String) onSave;

  const _ApiKeyField({
    required this.provider,
    required this.controller,
    required this.obscured,
    required this.isActive,
    required this.onToggleObscure,
    required this.onSave,
  });

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color:        AppTheme.surface,
      borderRadius: BorderRadius.circular(12),
      border:       Border.all(
        color: isActive
            ? AppTheme.accent.withOpacity(0.4)
            : AppTheme.surfaceBorder,
      ),
    ),
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ProviderBadge(provider: provider),
              const Spacer(),
              if (isActive)
                const Text(
                  'ACTIVE',
                  style: TextStyle(
                    fontFamily: 'JetBrainsMono',
                    fontSize: 9,
                    color: AppTheme.accent,
                    letterSpacing: 1,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller:  controller,
                  obscureText: obscured,
                  style: const TextStyle(
                    color:      AppTheme.textPrimary,
                    fontSize:   13,
                    fontFamily: 'JetBrainsMono',
                  ),
                  decoration: InputDecoration(
                    hintText: 'Paste API key here…',
                    hintStyle: const TextStyle(
                      color: AppTheme.textMuted, fontSize: 13),
                    border:       InputBorder.none,
                    isDense:      true,
                    contentPadding: EdgeInsets.zero,
                    suffixIcon: IconButton(
                      icon: Icon(
                        obscured ? Icons.visibility_off_rounded
                                 : Icons.visibility_rounded,
                        color: AppTheme.textMuted,
                        size: 18,
                      ),
                      onPressed: onToggleObscure,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () => onSave(controller.text.trim()),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color:        AppTheme.accent.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                    border:       Border.all(
                      color: AppTheme.accent.withOpacity(0.4)),
                  ),
                  child: const Text(
                    'Save',
                    style: TextStyle(
                      color:      AppTheme.accent,
                      fontSize:   13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

// ── Toggle setting ─────────────────────────────────────────────────────────────

class _ToggleSetting extends StatelessWidget {
  final String       label;
  final String       subtitle;
  final IconData     icon;
  final bool         value;
  final void Function(bool) onChanged;

  const _ToggleSetting({
    required this.label,
    required this.subtitle,
    required this.icon,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    decoration: BoxDecoration(
      color:        AppTheme.surface,
      borderRadius: BorderRadius.circular(12),
      border:       Border.all(color: AppTheme.surfaceBorder),
    ),
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          color:        AppTheme.accent.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: AppTheme.accent, size: 18),
      ),
      title: Text(label,
        style: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
      subtitle: Text(subtitle,
        style: const TextStyle(
          color: AppTheme.textSecondary,
          fontSize: 12,
        ),
      ),
      trailing: Switch.adaptive(
        value:           value,
        onChanged:       onChanged,
        activeColor:     AppTheme.accent,
        inactiveThumbColor: AppTheme.textMuted,
      ),
    ),
  );
}

// ── About card ─────────────────────────────────────────────────────────────────

class _AboutCard extends StatelessWidget {
  const _AboutCard();

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color:        AppTheme.surface,
      borderRadius: BorderRadius.circular(12),
      border:       Border.all(color: AppTheme.surfaceBorder),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 8, height: 8,
              decoration: BoxDecoration(
                color: AppTheme.accent,
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'Quiz Vision AI',
              style: TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color:        AppTheme.surfaceBorder,
                borderRadius: BorderRadius.circular(6),
              ),
              child: const Text(
                'v1.0.0',
                style: TextStyle(
                  fontFamily: 'JetBrainsMono',
                  fontSize: 10,
                  color: AppTheme.textMuted,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        const Text(
          'AI-powered MCQ solver using live camera OCR + multi-provider AI. '
          'Point camera at any multiple-choice question for instant answers.',
          style: TextStyle(
            color: AppTheme.textSecondary,
            fontSize: 12.5,
            height: 1.5,
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8, runSpacing: 6,
          children: const [
            _Tag('ML Kit OCR'),
            _Tag('GPT-4'),
            _Tag('Gemini'),
            _Tag('Claude'),
            _Tag('Offline Mode'),
            _Tag('TTS'),
          ],
        ),
      ],
    ),
  );
}

class _Tag extends StatelessWidget {
  final String label;
  const _Tag(this.label);

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(
      color:        AppTheme.surfaceBorder,
      borderRadius: BorderRadius.circular(6),
    ),
    child: Text(label,
      style: const TextStyle(
        fontFamily: 'JetBrainsMono',
        fontSize: 10,
        color: AppTheme.textSecondary,
      ),
    ),
  );
}
