import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import '../core/theme/app_theme.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../services/export_service.dart';
import '../widgets/shared_widgets.dart';

class HistoryScreen extends ConsumerStatefulWidget {
  const HistoryScreen({super.key});

  @override
  ConsumerState<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends ConsumerState<HistoryScreen> {
  final _searchCtrl = TextEditingController();
  bool _bookmarkOnly = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(historyProvider.notifier).refresh();
    });
    _searchCtrl.addListener(_onSearch);
  }

  void _onSearch() {
    ref.read(historyProvider.notifier).refresh(
      search:         _searchCtrl.text,
      bookmarkedOnly: _bookmarkOnly,
    );
  }

  Future<void> _export(List<HistoryEntry> entries, String format) async {
    final svc  = ref.read(exportServiceProvider);
    try {
      final path = format == 'csv'
          ? await svc.exportCsv(entries)
          : await svc.exportHtml(entries);
      await Share.shareXFiles([XFile(path)],
          text: 'Quiz Vision AI – history export');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Export failed: $e')));
      }
    }
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final historyAsync = ref.watch(historyProvider);

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('History'),
        actions: [
          historyAsync.whenOrNull(
            data: (entries) => PopupMenuButton<String>(
              icon: const Icon(Icons.file_download_outlined),
              color: AppTheme.surface,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              onSelected: (fmt) => _export(entries, fmt),
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'csv',  child: Text('Export CSV')),
                const PopupMenuItem(value: 'html', child: Text('Export HTML')),
              ],
            ),
          ) ?? const SizedBox(),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded),
            tooltip: 'Clear all',
            onPressed: () => _confirmClear(context),
          ),
        ],
      ),
      body: Column(
        children: [
          // Search + filter bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    style: const TextStyle(
                      color: AppTheme.textPrimary, fontSize: 14),
                    decoration: InputDecoration(
                      hintText:    'Search questions…',
                      hintStyle:   const TextStyle(
                        color: AppTheme.textMuted, fontSize: 14),
                      prefixIcon:  const Icon(Icons.search_rounded,
                                              color: AppTheme.textMuted, size: 18),
                      filled:      true,
                      fillColor:   AppTheme.surface,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: AppTheme.surfaceBorder),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: AppTheme.surfaceBorder),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: AppTheme.accent),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 10),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                _FilterChip(
                  label: 'Saved',
                  icon:  Icons.bookmark_rounded,
                  active: _bookmarkOnly,
                  onTap: () {
                    setState(() => _bookmarkOnly = !_bookmarkOnly);
                    _onSearch();
                  },
                ),
              ],
            ),
          ),

          // List
          Expanded(
            child: historyAsync.when(
              loading: () => const Center(
                child: CircularProgressIndicator(color: AppTheme.accent)),
              error: (e, _) => Center(
                child: Text('Error: $e',
                  style: const TextStyle(color: AppTheme.wrong))),
              data: (entries) => entries.isEmpty
                  ? _EmptyState()
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                      itemCount: entries.length,
                      itemBuilder: (_, i) => _HistoryCard(
                        entry: entries[i],
                        onBookmark: () => ref
                            .read(historyProvider.notifier)
                            .toggleBookmark(entries[i]),
                        onDelete: () => ref
                            .read(historyProvider.notifier)
                            .delete(entries[i].id!),
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmClear(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Clear all history?',
          style: TextStyle(color: AppTheme.textPrimary)),
        content: const Text('This cannot be undone.',
          style: TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel',
              style: TextStyle(color: AppTheme.textSecondary)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Clear',
              style: TextStyle(color: AppTheme.wrong)),
          ),
        ],
      ),
    );
    if (ok == true) {
      ref.read(historyProvider.notifier).clearAll();
    }
  }
}

// ── History card ───────────────────────────────────────────────────────────────

class _HistoryCard extends StatelessWidget {
  final HistoryEntry entry;
  final VoidCallback onBookmark;
  final VoidCallback onDelete;

  const _HistoryCard({
    required this.entry,
    required this.onBookmark,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final dateFmt = DateFormat('MMM d · HH:mm');

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color:        AppTheme.surface,
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: AppTheme.surfaceBorder),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top row
            Row(
              children: [
                Expanded(
                  child: Text(
                    entry.question,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w500,
                      height: 1.4,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 32, height: 32,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color:        AppTheme.correct.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                    border:       Border.all(
                      color: AppTheme.correct.withOpacity(0.4)),
                  ),
                  child: Text(
                    entry.answer,
                    style: const TextStyle(
                      fontFamily: 'JetBrainsMono',
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.correct,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),

            // Bottom row
            Row(
              children: [
                ConfidenceBar(value: entry.confidence),
                // reuse as mini inline
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                ProviderBadge(
                  provider: AiProvider.values.firstWhere(
                    (p) => p.name == entry.aiProvider,
                    orElse: () => AiProvider.offline,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  dateFmt.format(entry.timestamp),
                  style: const TextStyle(
                    fontFamily: 'JetBrainsMono',
                    fontSize: 10,
                    color: AppTheme.textMuted,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: onBookmark,
                  child: Icon(
                    entry.bookmarked
                        ? Icons.bookmark_rounded
                        : Icons.bookmark_outline_rounded,
                    color: entry.bookmarked
                        ? AppTheme.accentWarm
                        : AppTheme.textMuted,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: onDelete,
                  child: const Icon(Icons.delete_outline_rounded,
                                    color: AppTheme.textMuted, size: 18),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String     label;
  final IconData   icon;
  final bool       active;
  final VoidCallback onTap;

  const _FilterChip({
    required this.label,
    required this.icon,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color:        active
            ? AppTheme.accentWarm.withOpacity(0.15)
            : AppTheme.surface,
        borderRadius: BorderRadius.circular(12),
        border:       Border.all(
          color: active
              ? AppTheme.accentWarm.withOpacity(0.5)
              : AppTheme.surfaceBorder,
        ),
      ),
      child: Icon(icon,
        color: active ? AppTheme.accentWarm : AppTheme.textMuted,
        size: 18,
      ),
    ),
  );
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.history_edu_rounded,
                   color: AppTheme.textMuted, size: 48),
        const SizedBox(height: 16),
        const Text('No history yet',
          style: TextStyle(
            color: AppTheme.textSecondary,
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 8),
        const Text('Scan your first MCQ to get started',
          style: TextStyle(color: AppTheme.textMuted, fontSize: 13)),
      ],
    ),
  );
}
