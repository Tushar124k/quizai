import 'dart:async';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:permission_handler/permission_handler.dart';
import '../core/constants/app_constants.dart';
import '../core/theme/app_theme.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../widgets/answer_panel.dart';
import '../widgets/shared_widgets.dart';
import 'history_screen.dart';
import 'settings_screen.dart';

class CameraScreen extends ConsumerStatefulWidget {
  const CameraScreen({super.key});

  @override
  ConsumerState<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends ConsumerState<CameraScreen>
    with WidgetsBindingObserver {
  CameraController? _controller;
  List<CameraDescription> _cameras = [];
  bool _cameraReady   = false;
  bool _panelExpanded = false;
  bool _flashOn       = false;
  bool _isProcessing  = false;
  Timer? _scanTimer;

  final TextRecognizer _textRecognizer = TextRecognizer(
    script: TextRecognitionScript.latin,
  );

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    _requestPermissionsAndInit();
  }

  Future<void> _requestPermissionsAndInit() async {
    final status = await Permission.camera.request();
    if (status.isGranted) {
      await _initCamera();
    } else {
      setState(() => _cameraReady = false);
    }
  }

  Future<void> _initCamera() async {
    _cameras = await availableCameras();
    if (_cameras.isEmpty) return;

    final back = _cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => _cameras.first,
    );

    _controller = CameraController(
      back,
      ResolutionPreset.high,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.yuv420,
    );

    try {
      await _controller!.initialize();
      await _controller!.setFocusMode(FocusMode.auto);
      await _controller!.setExposureMode(ExposureMode.auto);
      if (mounted) {
        setState(() => _cameraReady = true);
        _startScanLoop();
      }
    } catch (_) {
      if (mounted) setState(() => _cameraReady = false);
    }
  }

  void _startScanLoop() {
    final settings = ref.read(settingsProvider).valueOrNull;
    if (settings?.autoScan == false) return;

    _scanTimer = Timer.periodic(
      const Duration(milliseconds: AppConstants.scanIntervalMs),
      (_) => _scanFrame(),
    );
  }

  Future<void> _scanFrame() async {
    if (!_cameraReady) return;
    if (_isProcessing)  return;
    if (_controller?.value.isInitialized != true) return;

    _isProcessing = true;
    try {
      final image = await _controller!.takePicture();
      final inputImage = InputImage.fromFilePath(image.path);
      final recognized = await _textRecognizer.processImage(inputImage);
      final rawText = recognized.text;

      if (rawText.trim().isNotEmpty) {
        await ref.read(scanProvider.notifier).processOcrText(rawText);
      }
    } catch (_) {
      // silently ignore per-frame errors
    } finally {
      _isProcessing = false;
    }
  }

  void _toggleFlash() async {
    if (_controller == null) return;
    setState(() => _flashOn = !_flashOn);
    await _controller!.setFlashMode(
      _flashOn ? FlashMode.torch : FlashMode.off,
    );
  }

  void _resetScan() {
    ref.read(scanProvider.notifier).reset();
    setState(() => _panelExpanded = false);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive) {
      _scanTimer?.cancel();
      _controller?.dispose();
    } else if (state == AppLifecycleState.resumed) {
      _initCamera();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _scanTimer?.cancel();
    _controller?.dispose();
    _textRecognizer.close();
    super.dispose();
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final scanResult = ref.watch(scanProvider);
    final settings   = ref.watch(settingsProvider).valueOrNull;

    return Scaffold(
      backgroundColor: AppTheme.background,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(settings),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ── Camera preview ──
          if (_cameraReady && _controller != null)
            _CameraPreview(controller: _controller!)
          else
            _NoCameraPlaceholder(
              onRetry: _requestPermissionsAndInit,
            ),

          // ── Viewfinder overlay ──
          const _ViewfinderOverlay(),

          // ── Top controls ──
          Positioned(
            top: MediaQuery.of(context).padding.top + kToolbarHeight + 8,
            right: 16,
            child: _SideControls(
              flashOn: _flashOn,
              onFlash: _toggleFlash,
              onReset: _resetScan,
              scanResult: scanResult,
            ),
          ),

          // ── Bottom answer panel ──
          Positioned(
            left: 0, right: 0, bottom: 0,
            child: AnswerPanel(
              result:         scanResult,
              expanded:       _panelExpanded,
              onToggleExpand: () => setState(() => _panelExpanded = !_panelExpanded),
            ),
          ),
        ],
      ),
    );
  }

  AppBar _buildAppBar(AppSettings? settings) => AppBar(
    title: Row(
      children: [
        Container(
          width: 8, height: 8,
          decoration: BoxDecoration(
            color: AppTheme.accent,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 8),
        const Text('Quiz Vision AI'),
      ],
    ),
    actions: [
      if (settings != null)
        Padding(
          padding: const EdgeInsets.only(right: 4),
          child: ProviderBadge(provider: settings.aiProvider),
        ),
      IconButton(
        icon: const Icon(Icons.history_rounded),
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const HistoryScreen()),
        ),
        tooltip: 'History',
      ),
      IconButton(
        icon: const Icon(Icons.settings_rounded),
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const SettingsScreen()),
        ),
        tooltip: 'Settings',
      ),
    ],
  );
}

// ── Camera preview wrapper ─────────────────────────────────────────────────────

class _CameraPreview extends StatelessWidget {
  final CameraController controller;
  const _CameraPreview({required this.controller});

  @override
  Widget build(BuildContext context) {
    final size   = MediaQuery.of(context).size;
    final aspect = controller.value.aspectRatio;
    return SizedBox.expand(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width:  size.width,
          height: size.width / aspect,
          child:  CameraPreview(controller),
        ),
      ),
    );
  }
}

// ── Viewfinder scanning overlay ────────────────────────────────────────────────

class _ViewfinderOverlay extends StatelessWidget {
  const _ViewfinderOverlay();

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final w    = size.width  * 0.88;
    final h    = size.height * 0.30;

    return Center(
      child: CustomPaint(
        size: Size(w, h),
        painter: _CornerPainter(),
      ),
    );
  }
}

class _CornerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color       = AppTheme.accent.withOpacity(0.8)
      ..strokeWidth = 2.5
      ..style       = PaintingStyle.stroke
      ..strokeCap   = StrokeCap.round;

    const len = 24.0;
    final r   = Offset.zero & size;

    // Corners
    for (final (ox, oy, dx, dy) in [
      (r.left,  r.top,    1.0,  1.0),
      (r.right, r.top,   -1.0,  1.0),
      (r.left,  r.bottom, 1.0, -1.0),
      (r.right, r.bottom,-1.0, -1.0),
    ]) {
      canvas
        ..drawLine(Offset(ox, oy), Offset(ox + dx * len, oy), paint)
        ..drawLine(Offset(ox, oy), Offset(ox, oy + dy * len), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ── No camera placeholder ──────────────────────────────────────────────────────

class _NoCameraPlaceholder extends StatelessWidget {
  final VoidCallback onRetry;
  const _NoCameraPlaceholder({required this.onRetry});

  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.no_photography_outlined,
                   color: AppTheme.textMuted, size: 48),
        const SizedBox(height: 16),
        const Text(
          'Camera permission required',
          style: TextStyle(color: AppTheme.textSecondary),
        ),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: onRetry,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppTheme.accent,
            foregroundColor: AppTheme.background,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: const Text('Grant Permission'),
        ),
      ],
    ),
  );
}

// ── Side controls ──────────────────────────────────────────────────────────────

class _SideControls extends StatelessWidget {
  final bool       flashOn;
  final VoidCallback onFlash;
  final VoidCallback onReset;
  final ScanResult   scanResult;

  const _SideControls({
    required this.flashOn,
    required this.onFlash,
    required this.onReset,
    required this.scanResult,
  });

  @override
  Widget build(BuildContext context) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      _ControlBtn(
        icon:   flashOn ? Icons.flash_on_rounded : Icons.flash_off_rounded,
        active: flashOn,
        onTap:  onFlash,
        tooltip: 'Flash',
      ),
      const SizedBox(height: 10),
      _ControlBtn(
        icon:    Icons.refresh_rounded,
        active:  false,
        onTap:   onReset,
        tooltip: 'Reset scan',
      ),
    ],
  );
}

class _ControlBtn extends StatelessWidget {
  final IconData   icon;
  final bool       active;
  final VoidCallback onTap;
  final String     tooltip;

  const _ControlBtn({
    required this.icon,
    required this.active,
    required this.onTap,
    required this.tooltip,
  });

  @override
  Widget build(BuildContext context) => Tooltip(
    message: tooltip,
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44, height: 44,
        decoration: BoxDecoration(
          color:  active
              ? AppTheme.accent.withOpacity(0.2)
              : AppTheme.background.withOpacity(0.7),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: active ? AppTheme.accent.withOpacity(0.6) : AppTheme.surfaceBorder,
          ),
        ),
        child: Icon(icon,
          color: active ? AppTheme.accent : AppTheme.textSecondary,
          size: 20,
        ),
      ),
    ),
  );
}
