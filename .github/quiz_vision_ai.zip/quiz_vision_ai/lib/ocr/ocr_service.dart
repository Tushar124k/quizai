import 'dart:typed_data';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import '../models/models.dart';
import '../core/constants/app_constants.dart';

/// Wraps Google ML Kit text recognition.
/// Parsing logic extracts question + 4 options from raw OCR output.
class OcrService {
  final TextRecognizer _recognizer = TextRecognizer(
    script: TextRecognitionScript.latin,
  );

  // ── Public API ─────────────────────────────────────────────────────────────

  Future<McqQuestion?> recognizeFromBytes({
    required Uint8List bytes,
    required int width,
    required int height,
    required InputImageRotation rotation,
    required InputImageFormat format,
  }) async {
    final inputImage = InputImage.fromBytes(
      bytes: bytes,
      metadata: InputImageMetadata(
        size: Size(width.toDouble(), height.toDouble()),
        rotation: rotation,
        format: format,
        bytesPerRow: width * 4,
      ),
    );
    return _recognizeFromInputImage(inputImage);
  }

  Future<McqQuestion?> recognizeFromFile(String path) async {
    final inputImage = InputImage.fromFilePath(path);
    return _recognizeFromInputImage(inputImage);
  }

  Future<void> dispose() async {
    await _recognizer.close();
  }

  // ── Internal ───────────────────────────────────────────────────────────────

  Future<McqQuestion?> _recognizeFromInputImage(InputImage image) async {
    try {
      final recognized = await _recognizer.processImage(image);
      final rawText = recognized.text;
      if (rawText.trim().isEmpty) return null;
      return _parseQuestion(rawText);
    } catch (_) {
      return null;
    }
  }

  McqQuestion? _parseQuestion(String rawText) {
    final lines = rawText
        .split('\n')
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();

    if (lines.isEmpty) return null;

    String? questionNumber;
    String questionText = '';
    String? optA, optB, optC, optD;

    final optionRe = RegExp(
      r'^([A-Da-d])[.\):\s]\s*(.+)$',
      caseSensitive: false,
    );
    final questionNumRe = RegExp(r'^(\d+)[.\)]\s*(.*)$');

    final questionLines = <String>[];
    bool questionDone = false;

    for (final line in lines) {
      // Match option lines A-D
      final optMatch = optionRe.firstMatch(line);
      if (optMatch != null) {
        questionDone = true;
        final letter = optMatch.group(1)!.toUpperCase();
        final text   = optMatch.group(2)!.trim();
        switch (letter) {
          case 'A': optA = text;
          case 'B': optB = text;
          case 'C': optC = text;
          case 'D': optD = text;
        }
        continue;
      }

      if (!questionDone) {
        // Try to detect question number
        final qNumMatch = questionNumRe.firstMatch(line);
        if (qNumMatch != null && questionLines.isEmpty) {
          questionNumber = qNumMatch.group(1);
          final rest = qNumMatch.group(2)!.trim();
          if (rest.isNotEmpty) questionLines.add(rest);
        } else {
          questionLines.add(line);
        }
      }
    }

    questionText = questionLines.join(' ').trim();

    // Need at least a question and one option to be useful
    if (questionText.length < 8) return null;
    if (optA == null && optB == null && optC == null && optD == null) {
      // No options found — still try to return question-only for AI
      if (questionText.length < 20) return null;
    }

    return McqQuestion(
      questionNumber: questionNumber,
      questionText:   questionText,
      optionA:        optA,
      optionB:        optB,
      optionC:        optC,
      optionD:        optD,
      rawText:        rawText,
    );
  }
}

// Extension so Size is usable without dart:ui import everywhere
class Size {
  final double width, height;
  const Size(this.width, this.height);
}
