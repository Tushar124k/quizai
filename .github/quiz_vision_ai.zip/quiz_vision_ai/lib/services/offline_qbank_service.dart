import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import '../models/models.dart';
import '../core/constants/app_constants.dart';

/// Searches a locally stored question bank for matching MCQs.
/// Falls back gracefully when the bank is empty.
class OfflineQBankService {
  Database? _db;

  Future<Database> get db async {
    _db ??= await _openDb();
    return _db!;
  }

  Future<Database> _openDb() async {
    final path = p.join(await getDatabasesPath(), AppConstants.dbName);
    return openDatabase(
      path,
      version: AppConstants.dbVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE ${AppConstants.historyTable} (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        question    TEXT    NOT NULL,
        option_a    TEXT,
        option_b    TEXT,
        option_c    TEXT,
        option_d    TEXT,
        answer      TEXT    NOT NULL,
        confidence  REAL    NOT NULL DEFAULT 1.0,
        explanation TEXT,
        ai_provider TEXT    NOT NULL,
        timestamp   INTEGER NOT NULL,
        bookmarked  INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE ${AppConstants.offlineQBank} (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        question   TEXT NOT NULL,
        option_a   TEXT,
        option_b   TEXT,
        option_c   TEXT,
        option_d   TEXT,
        answer     TEXT NOT NULL,
        subject    TEXT,
        tags       TEXT
      )
    ''');

    await db.execute('''
      CREATE INDEX idx_history_ts ON ${AppConstants.historyTable}(timestamp DESC)
    ''');
    await db.execute('''
      CREATE INDEX idx_qbank_question ON ${AppConstants.offlineQBank}(question)
    ''');
  }

  Future<void> _onUpgrade(Database db, int oldV, int newV) async {
    // future migrations here
  }

  // ── Offline search ─────────────────────────────────────────────────────────

  Future<AiAnswer?> search(McqQuestion question) async {
    final database = await db;
    final words = _keyWords(question.questionText);
    if (words.isEmpty) return null;

    // Build a LIKE query for every keyword
    final conditions = words.map((_) => 'question LIKE ?').join(' AND ');
    final args = words.map((w) => '%$w%').toList();

    final rows = await database.query(
      AppConstants.offlineQBank,
      where: conditions,
      whereArgs: args,
      limit: 5,
    );

    if (rows.isEmpty) return null;

    // Score by word overlap and pick best
    final scored = rows.map((r) {
      final q = (r['question'] as String).toLowerCase();
      final overlap = words.where((w) => q.contains(w)).length;
      return (row: r, score: overlap / words.length);
    }).toList()
      ..sort((a, b) => b.score.compareTo(a.score));

    final best = scored.first;
    if (best.score < 0.5) return null;

    return AiAnswer(
      answer:      best.row['answer'] as String,
      confidence:  best.score,
      explanation: 'Matched from offline question bank.',
      source:      AiProvider.offline,
      fromCache:   true,
    );
  }

  List<String> _keyWords(String text) => text
      .toLowerCase()
      .replaceAll(RegExp(r'[^\w\s]'), ' ')
      .split(RegExp(r'\s+'))
      .where((w) => w.length > 4)
      .take(8)
      .toList();

  // ── History CRUD ───────────────────────────────────────────────────────────

  Future<int> insertHistory(HistoryEntry entry) async {
    final database = await db;
    return database.insert(AppConstants.historyTable, entry.toMap());
  }

  Future<List<HistoryEntry>> queryHistory({
    String? search,
    bool? bookmarkedOnly,
    int limit = 100,
    int offset = 0,
  }) async {
    final database = await db;
    final conditions = <String>[];
    final args      = <dynamic>[];

    if (search != null && search.isNotEmpty) {
      conditions.add('question LIKE ?');
      args.add('%$search%');
    }
    if (bookmarkedOnly == true) {
      conditions.add('bookmarked = 1');
    }

    final rows = await database.query(
      AppConstants.historyTable,
      where: conditions.isEmpty ? null : conditions.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'timestamp DESC',
      limit: limit,
      offset: offset,
    );
    return rows.map(HistoryEntry.fromMap).toList();
  }

  Future<void> toggleBookmark(int id, bool bookmarked) async {
    final database = await db;
    await database.update(
      AppConstants.historyTable,
      {'bookmarked': bookmarked ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> deleteHistory(int id) async {
    final database = await db;
    await database.delete(
      AppConstants.historyTable,
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> clearAllHistory() async {
    final database = await db;
    await database.delete(AppConstants.historyTable);
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
  }
}
