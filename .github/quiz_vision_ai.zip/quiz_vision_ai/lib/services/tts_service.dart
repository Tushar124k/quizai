import 'package:flutter_tts/flutter_tts.dart';
import '../models/models.dart';

class TtsService {
  final FlutterTts _tts = FlutterTts();
  bool _initialized = false;

  Future<void> _init() async {
    if (_initialized) return;
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(0.95);
    await _tts.setVolume(1.0);
    await _tts.setPitch(1.0);
    _initialized = true;
  }

  Future<void> speakAnswer(McqQuestion question, AiAnswer answer) async {
    await _init();
    final optText = question.optionText(answer.answer) ?? '';
    final text = 'The answer is option ${answer.answer}. '
        '${optText.isNotEmpty ? "$optText. " : ""}'
        'Confidence: ${answer.confidencePct} percent. '
        '${answer.explanation?.isNotEmpty == true ? answer.explanation! : ""}';
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> speak(String text) async {
    await _init();
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> stop() async => _tts.stop();
  Future<void> dispose() async => _tts.stop();
}
