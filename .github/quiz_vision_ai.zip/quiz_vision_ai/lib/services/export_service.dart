import 'dart:io';
import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';

class ExportService {
  static final _dateFmt = DateFormat('yyyy-MM-dd HH:mm');
  static final _fileFmt = DateFormat('yyyyMMdd_HHmmss');

  // ── CSV ────────────────────────────────────────────────────────────────────

  Future<String> exportCsv(List<HistoryEntry> entries) async {
    final rows = <List<dynamic>>[
      ['#', 'Question', 'A', 'B', 'C', 'D', 'Answer', 'Confidence%', 'AI', 'Time'],
      ...entries.asMap().entries.map((e) => [
        e.key + 1,
        e.value.question,
        e.value.optionA ?? '',
        e.value.optionB ?? '',
        e.value.optionC ?? '',
        e.value.optionD ?? '',
        e.value.answer,
        (e.value.confidence * 100).toStringAsFixed(0),
        e.value.aiProvider,
        _dateFmt.format(e.value.timestamp),
      ]),
    ];

    final csv  = const ListToCsvConverter().convert(rows);
    final dir  = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/quiz_export_${_fileFmt.format(DateTime.now())}.csv';
    await File(path).writeAsString(csv);
    return path;
  }

  // ── Simple HTML "PDF" ──────────────────────────────────────────────────────
  // (Using html→pdf via the pdf package requires font assets;
  //  we output a well-formatted HTML file that can be printed to PDF.)

  Future<String> exportHtml(List<HistoryEntry> entries) async {
    final buf = StringBuffer();
    buf.write('''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Quiz Vision AI – History</title>
<style>
  body { font-family: Arial, sans-serif; padding: 24px; color: #1a1a2e; }
  h1 { color: #00E5B4; }
  table { width: 100%; border-collapse: collapse; margin-top: 16px; }
  th { background: #12151C; color: #F0F4FF; padding: 10px 12px; text-align: left; }
  td { padding: 8px 12px; border-bottom: 1px solid #e0e0e0; font-size: 13px; }
  .ans { font-weight: bold; color: #1AE86D; }
  .conf { color: #888; }
  tr:nth-child(even) td { background: #f9f9f9; }
</style>
</head>
<body>
<h1>Quiz Vision AI – History Export</h1>
<p>Exported: ${_dateFmt.format(DateTime.now())} &nbsp;|&nbsp; ${entries.length} questions</p>
<table>
<tr><th>#</th><th>Question</th><th>Options</th><th>Answer</th><th>Confidence</th><th>AI</th><th>Time</th></tr>
''');

    for (var i = 0; i < entries.length; i++) {
      final e = entries[i];
      final opts = [
        if (e.optionA != null) 'A) ${e.optionA}',
        if (e.optionB != null) 'B) ${e.optionB}',
        if (e.optionC != null) 'C) ${e.optionC}',
        if (e.optionD != null) 'D) ${e.optionD}',
      ].join('<br>');

      buf.write('''
<tr>
  <td>${i + 1}</td>
  <td>${_esc(e.question)}</td>
  <td>$opts</td>
  <td class="ans">${e.answer}</td>
  <td class="conf">${(e.confidence * 100).toStringAsFixed(0)}%</td>
  <td>${e.aiProvider}</td>
  <td>${_dateFmt.format(e.timestamp)}</td>
</tr>
''');
    }

    buf.write('</table></body></html>');

    final dir  = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/quiz_export_${_fileFmt.format(DateTime.now())}.html';
    await File(path).writeAsString(buf.toString());
    return path;
  }

  String _esc(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;');
}
