import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';
import '../core/constants/app_constants.dart';

class SettingsService {
  SharedPreferences? _prefs;

  Future<SharedPreferences> get prefs async {
    _prefs ??= await SharedPreferences.getInstance();
    return _prefs!;
  }

  Future<AppSettings> load() async {
    final p = await prefs;

    final providerStr = p.getString(AppConstants.kAiProvider) ?? 'gemini';
    final provider = AiProvider.values.firstWhere(
      (e) => e.name == providerStr,
      orElse: () => AiProvider.gemini,
    );

    final keys = <AiProvider, String>{};
    for (final prov in AiProvider.values) {
      final key = p.getString('${AppConstants.kApiKey}${prov.name}');
      if (key != null && key.isNotEmpty) {
        keys[prov] = key;
      }
    }

    return AppSettings(
      aiProvider:   provider,
      apiKeys:      keys,
      speakAnswer:  p.getBool(AppConstants.kSpeakAnswer)  ?? false,
      autoScan:     p.getBool(AppConstants.kAutoScan)     ?? true,
      offlineFirst: p.getBool(AppConstants.kOfflineFirst) ?? false,
    );
  }

  Future<void> save(AppSettings settings) async {
    final p = await prefs;
    await p.setString(AppConstants.kAiProvider, settings.aiProvider.name);
    await p.setBool(AppConstants.kSpeakAnswer,  settings.speakAnswer);
    await p.setBool(AppConstants.kAutoScan,     settings.autoScan);
    await p.setBool(AppConstants.kOfflineFirst, settings.offlineFirst);

    for (final entry in settings.apiKeys.entries) {
      await p.setString('${AppConstants.kApiKey}${entry.key.name}', entry.value);
    }
  }

  Future<void> setApiKey(AiProvider provider, String key) async {
    final p = await prefs;
    await p.setString('${AppConstants.kApiKey}${provider.name}', key);
  }

  Future<String?> getApiKey(AiProvider provider) async {
    final p = await prefs;
    return p.getString('${AppConstants.kApiKey}${provider.name}');
  }
}
