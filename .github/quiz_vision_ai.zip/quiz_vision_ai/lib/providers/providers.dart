import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../ai/ai_service.dart';
import '../ocr/ocr_service.dart';
import '../services/offline_qbank_service.dart';
import '../services/settings_service.dart';
import '../services/export_service.dart';
import '../services/tts_service.dart';
import '../core/constants/app_constants.dart';

// ── Service singletons ─────────────────────────────────────────────────────────

final settingsServiceProvider = Provider((ref) => SettingsService());
final aiServiceProvider        = Provider((ref) => AiService());
final ocrServiceProvider       = Provider((ref) => OcrService());
final dbServiceProvider        = Provider((ref) => OfflineQBankService());
final exportServiceProvider    = Provider((ref) => ExportService());
final ttsServiceProvider       = Provider((ref) => TtsService());

// ── Settings ───────────────────────────────────────────────────────────────────

class SettingsNotifier extends AsyncNotifier<AppSettings> {
  @override
  Future<AppSettings> build() async {
    final svc = ref.read(settingsServiceProvider);
    return svc.load();
  }

  Future<void> update(AppSettings updated) async {
    state = AsyncData(updated);
    await ref.read(settingsServiceProvider).save(updated);
  }

  Future<void> setApiKey(AiProvider provider, String key) async {
    final current = state.valueOrNull;
    if (current == null) return;
    final newKeys = Map<AiProvider, String>.from(current.apiKeys)
      ..[provider] = key;
    await update(current.copyWith(apiKeys: newKeys));
  }
}

final settingsProvider =
    AsyncNotifierProvider<SettingsNotifier, AppSettings>(SettingsNotifier.new);

// ── Scan state ─────────────────────────────────────────────────────────────────

class ScanNotifier extends Notifier<ScanResult> {
  @override
  ScanResult build() => ScanResult(status: ScanStatus.idle);

  String? _lastFingerprint;
  bool    _processing = false;

  /// Called by the camera loop with raw OCR output.
  Future<void> processOcrText(String rawText) async {
    if (_processing) return;

    // Quick text check
    if (rawText.trim().length < 10) return;

    _processing = true;
    state = state.copyWith(status: ScanStatus.detecting);

    try {
      final ocrSvc = ref.read(ocrServiceProvider);
      final question = await Future(() => _parseTextDirectly(rawText));

      if (question == null) {
        state = state.copyWith(status: ScanStatus.idle);
        return;
      }

      // Deduplicate
      if (question.fingerprint == _lastFingerprint) {
        state = state.copyWith(status: ScanStatus.done);
        return;
      }

      _lastFingerprint = question.fingerprint;
      state = state.copyWith(status: ScanStatus.ai, question: question);

      // Fetch AI answer
      final answer = await _fetchAnswer(question);

      if (answer != null) {
        state = state.copyWith(status: ScanStatus.done, answer: answer);

        // Auto-save to history
        final settings = ref.read(settingsProvider).valueOrNull;
        final db = ref.read(dbServiceProvider);
        await db.insertHistory(HistoryEntry(
          question:    question.questionText,
          optionA:     question.optionA,
          optionB:     question.optionB,
          optionC:     question.optionC,
          optionD:     question.optionD,
          answer:      answer.answer,
          confidence:  answer.confidence,
          explanation: answer.explanation,
          aiProvider:  answer.source.name,
          timestamp:   DateTime.now(),
        ));

        // TTS
        if (settings?.speakAnswer == true) {
          await ref.read(ttsServiceProvider).speakAnswer(question, answer);
        }
      } else {
        state = state.copyWith(status: ScanStatus.error, errorMessage: 'No answer found');
      }
    } catch (e) {
      state = state.copyWith(
        status: ScanStatus.error,
        errorMessage: e.toString(),
      );
    } finally {
      _processing = false;
    }
  }

  Future<AiAnswer?> _fetchAnswer(McqQuestion question) async {
    final settings = ref.read(settingsProvider).valueOrNull;
    if (settings == null) return null;

    // Offline-first mode
    if (settings.offlineFirst) {
      final db     = ref.read(dbServiceProvider);
      final local  = await db.search(question);
      if (local != null) return local;
    }

    final provider = settings.aiProvider;
    if (provider == AiProvider.offline) {
      return ref.read(dbServiceProvider).search(question);
    }

    final apiKey = settings.apiKeyFor(provider) ?? '';
    if (apiKey.isEmpty) {
      // Fallback to offline
      return ref.read(dbServiceProvider).search(question);
    }

    return ref.read(aiServiceProvider).solve(
      question: question,
      provider: provider,
      apiKey:   apiKey,
    );
  }

  McqQuestion? _parseTextDirectly(String rawText) {
    // Inline mini-parser (isolate-free for simplicity; OCR service used for full flow)
    final lines = rawText
        .split('\n')
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();

    if (lines.isEmpty) return null;

    final optionRe = RegExp(r'^([A-Da-d])[.\):\s]\s*(.+)$');
    String? qNum, optA, optB, optC, optD;
    final qLines = <String>[];

    for (final line in lines) {
      final m = optionRe.firstMatch(line);
      if (m != null) {
        final l = m.group(1)!.toUpperCase();
        final t = m.group(2)!.trim();
        switch (l) {
          case 'A': optA = t;
          case 'B': optB = t;
          case 'C': optC = t;
          case 'D': optD = t;
        }
      } else if (optA == null) {
        final qm = RegExp(r'^(\d+)[.\)]\s*(.*)$').firstMatch(line);
        if (qm != null && qLines.isEmpty) {
          qNum = qm.group(1);
          if ((qm.group(2) ?? '').isNotEmpty) qLines.add(qm.group(2)!);
        } else {
          qLines.add(line);
        }
      }
    }

    final qText = qLines.join(' ').trim();
    if (qText.length < 8) return null;

    return McqQuestion(
      questionNumber: qNum,
      questionText:   qText,
      optionA: optA, optionB: optB, optionC: optC, optionD: optD,
      rawText: rawText,
    );
  }

  void reset() {
    _lastFingerprint = null;
    state = ScanResult(status: ScanStatus.idle);
  }
}

final scanProvider = NotifierProvider<ScanNotifier, ScanResult>(ScanNotifier.new);

// ── History ────────────────────────────────────────────────────────────────────

class HistoryNotifier extends AsyncNotifier<List<HistoryEntry>> {
  @override
  Future<List<HistoryEntry>> build() async {
    return ref.read(dbServiceProvider).queryHistory();
  }

  Future<void> refresh({String? search, bool? bookmarkedOnly}) async {
    state = const AsyncLoading();
    state = AsyncData(
      await ref.read(dbServiceProvider).queryHistory(
        search:         search,
        bookmarkedOnly: bookmarkedOnly,
      ),
    );
  }

  Future<void> toggleBookmark(HistoryEntry entry) async {
    if (entry.id == null) return;
    await ref.read(dbServiceProvider).toggleBookmark(entry.id!, !entry.bookmarked);
    await refresh();
  }

  Future<void> delete(int id) async {
    await ref.read(dbServiceProvider).deleteHistory(id);
    await refresh();
  }

  Future<void> clearAll() async {
    await ref.read(dbServiceProvider).clearAllHistory();
    state = const AsyncData([]);
  }
}

final historyProvider =
    AsyncNotifierProvider<HistoryNotifier, List<HistoryEntry>>(HistoryNotifier.new);

// ── Search query ───────────────────────────────────────────────────────────────
final historySearchProvider = StateProvider<String>((ref) => '');
final historyBookmarkFilterProvider = StateProvider<bool>((ref) => false);
