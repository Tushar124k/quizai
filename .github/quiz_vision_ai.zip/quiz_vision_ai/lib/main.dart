import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/theme/app_theme.dart';
import 'screens/camera_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Edge-to-edge immersive display
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:            Colors.transparent,
    statusBarIconBrightness:   Brightness.light,
    systemNavigationBarColor:  Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  runApp(const ProviderScope(child: QuizVisionApp()));
}

class QuizVisionApp extends StatelessWidget {
  const QuizVisionApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title:        'Quiz Vision AI',
    debugShowCheckedModeBanner: false,
    theme:        AppTheme.dark,
    darkTheme:    AppTheme.dark,
    themeMode:    ThemeMode.dark,
    home:         const CameraScreen(),
  );
}
