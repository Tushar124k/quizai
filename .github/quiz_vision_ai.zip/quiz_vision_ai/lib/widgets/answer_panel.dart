import 'package:flutter/material.dart';
import '../models/models.dart';
import '../core/theme/app_theme.dart';
import 'shared_widgets.dart';

/// Bottom glass panel overlaid on the camera showing detected Q+A.
class AnswerPanel extends StatelessWidget {
  final ScanResult result;
  final bool        expanded;
  final VoidCallback onToggleExpand;

  const AnswerPanel({
    super.key,
    required this.result,
    required this.expanded,
    required this.onToggleExpand,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onToggleExpand,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve:    Curves.easeOutCubic,
        padding:  const EdgeInsets.fromLTRB(16, 12, 16, 24),
        decoration: BoxDecoration(
          color: AppTheme.background.withOpacity(0.92),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: const Border(
            top: BorderSide(color: AppTheme.surfaceBorder, width: 1),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Drag handle
            Center(
              child: Container(
                width: 36, height: 4,
                margin: const EdgeInsets.only(bottom: 14),
                decoration: BoxDecoration(
                  color: AppTheme.textMuted,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),

            // Status row
            Row(
              children: [
                StatusBadge(status: result.status),
                const Spacer(),
                if (result.answer != null)
                  ProviderBadge(provider: result.answer!.source),
              ],
            ),

            const SizedBox(height: 12),

            // Idle state
            if (result.status == ScanStatus.idle)
              _IdleHint(),

            // Processing state
            if (result.status == ScanStatus.detecting ||
                result.status == ScanStatus.ocr ||
                result.status == ScanStatus.ai)
              _ProcessingIndicator(status: result.status),

            // Done state
            if (result.status == ScanStatus.done && result.question != null)
              _ResultContent(
                question: result.question!,
                answer:   result.answer,
                expanded: expanded,
              ),

            // Error state
            if (result.status == ScanStatus.error)
              _ErrorHint(message: result.errorMessage),
          ],
        ),
      ),
    );
  }
}

// ── Sub-widgets ────────────────────────────────────────────────────────────────

class _IdleHint extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Row(
    children: [
      const Icon(Icons.camera_alt_outlined,
                 color: AppTheme.textMuted, size: 18),
      const SizedBox(width: 10),
      Text(
        'Point camera at an MCQ question',
        style: const TextStyle(
          color: AppTheme.textSecondary,
          fontSize: 14,
        ),
      ),
    ],
  );
}

class _ProcessingIndicator extends StatelessWidget {
  final ScanStatus status;
  const _ProcessingIndicator({required this.status});

  String get _label => switch (status) {
    ScanStatus.detecting => 'Detecting question...',
    ScanStatus.ocr       => 'Reading text...',
    ScanStatus.ai        => 'Getting AI answer...',
    _                    => 'Processing...',
  };

  @override
  Widget build(BuildContext context) => Row(
    children: [
      SizedBox(
        width: 16, height: 16,
        child: CircularProgressIndicator(
          strokeWidth: 2,
          color: AppTheme.accent,
        ),
      ),
      const SizedBox(width: 10),
      Text(_label,
        style: const TextStyle(
          color: AppTheme.textSecondary,
          fontSize: 14,
        ),
      ),
    ],
  );
}

class _ResultContent extends StatelessWidget {
  final McqQuestion question;
  final AiAnswer?   answer;
  final bool        expanded;

  const _ResultContent({
    required this.question,
    required this.answer,
    required this.expanded,
  });

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      // Question text (truncated when collapsed)
      Text(
        question.questionNumber != null
            ? 'Q${question.questionNumber}. ${question.questionText}'
            : question.questionText,
        maxLines: expanded ? 6 : 2,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          color: AppTheme.textPrimary,
          fontSize: 14,
          height: 1.45,
          fontWeight: FontWeight.w500,
        ),
      ),

      if (answer != null) ...[
        const SizedBox(height: 12),
        ConfidenceBar(value: answer!.confidence),
        const SizedBox(height: 12),

        // Answer highlight row
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: AppTheme.correct.withOpacity(0.12),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: AppTheme.correct.withOpacity(0.5),
              width: 1.5,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 36, height: 36,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color:        AppTheme.correct,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  answer!.answer,
                  style: const TextStyle(
                    fontFamily: 'JetBrainsMono',
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: AppTheme.background,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'CORRECT ANSWER',
                      style: TextStyle(
                        fontFamily: 'JetBrainsMono',
                        fontSize: 9,
                        letterSpacing: 1,
                        color: AppTheme.correct.withOpacity(0.7),
                      ),
                    ),
                    if (question.optionText(answer!.answer) != null)
                      Text(
                        question.optionText(answer!.answer)!,
                        style: const TextStyle(
                          color: AppTheme.correct,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          height: 1.3,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                  ],
                ),
              ),
              Icon(Icons.check_circle_rounded,
                   color: AppTheme.correct, size: 22),
            ],
          ),
        ),

        // Expanded options
        if (expanded && question.hasOptions) ...[
          const SizedBox(height: 12),
          _buildOptions(question, answer!.answer),
        ],

        // Explanation
        if (expanded && answer!.explanation?.isNotEmpty == true) ...[
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color:        AppTheme.accentWarm.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border:       Border.all(
                color: AppTheme.accentWarm.withOpacity(0.2),
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.lightbulb_outline_rounded,
                     color: AppTheme.accentWarm, size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    answer!.explanation!,
                    style: TextStyle(
                      color: AppTheme.accentWarm.withOpacity(0.9),
                      fontSize: 12.5,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    ],
  );

  Widget _buildOptions(McqQuestion q, String correct) => Column(
    children: [
      for (final letter in ['A', 'B', 'C', 'D'])
        if (q.optionText(letter) != null)
          OptionChip(
            letter:       letter,
            text:         q.optionText(letter)!,
            isCorrect:    letter == correct,
          ),
    ],
  );
}

class _ErrorHint extends StatelessWidget {
  final String? message;
  const _ErrorHint({this.message});

  @override
  Widget build(BuildContext context) => Row(
    children: [
      const Icon(Icons.error_outline_rounded,
                 color: AppTheme.wrong, size: 18),
      const SizedBox(width: 10),
      Expanded(
        child: Text(
          message ?? 'Could not process question',
          style: const TextStyle(color: AppTheme.wrong, fontSize: 13),
        ),
      ),
    ],
  );
}
