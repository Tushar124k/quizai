import 'package:flutter/material.dart';
import 'dart:ui';
import '../core/theme/app_theme.dart';
import '../models/models.dart';

// ── Glass Card ─────────────────────────────────────────────────────────────────

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double radius;
  final Color? borderColor;
  final double blur;

  const GlassCard({
    super.key,
    required this.child,
    this.padding,
    this.radius = 16,
    this.borderColor,
    this.blur = 12,
  });

  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(radius),
    child: BackdropFilter(
      filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
      child: Container(
        padding: padding ?? const EdgeInsets.all(16),
        decoration: glassDecoration(
          radius: radius,
          borderColor: borderColor,
        ),
        child: child,
      ),
    ),
  );
}

// ── Option chip ────────────────────────────────────────────────────────────────

class OptionChip extends StatelessWidget {
  final String letter;
  final String text;
  final bool   isCorrect;
  final bool   isHighlighted;
  final double confidence;

  const OptionChip({
    super.key,
    required this.letter,
    required this.text,
    this.isCorrect      = false,
    this.isHighlighted  = false,
    this.confidence     = 0,
  });

  @override
  Widget build(BuildContext context) {
    Color bg, border, textColor;
    if (isCorrect) {
      bg        = AppTheme.correct.withOpacity(0.15);
      border    = AppTheme.correct.withOpacity(0.7);
      textColor = AppTheme.correct;
    } else if (isHighlighted) {
      bg        = AppTheme.accent.withOpacity(0.08);
      border    = AppTheme.accent.withOpacity(0.3);
      textColor = AppTheme.textSecondary;
    } else {
      bg        = Colors.transparent;
      border    = AppTheme.surfaceBorder;
      textColor = AppTheme.textSecondary;
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color:        bg,
        borderRadius: BorderRadius.circular(12),
        border:       Border.all(color: border, width: isCorrect ? 1.5 : 1),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Letter badge
            Container(
              width: 28, height: 28,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color:        isCorrect ? AppTheme.correct : AppTheme.surfaceBorder,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                letter,
                style: TextStyle(
                  fontFamily: 'JetBrainsMono',
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: isCorrect ? AppTheme.background : AppTheme.textPrimary,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                text,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: isCorrect ? FontWeight.w600 : FontWeight.w400,
                  color: isCorrect ? AppTheme.correct : textColor,
                  height: 1.4,
                ),
              ),
            ),
            if (isCorrect) ...[
              const SizedBox(width: 8),
              Icon(Icons.check_circle_rounded,
                   color: AppTheme.correct, size: 18),
            ],
          ],
        ),
      ),
    );
  }
}

// ── Status badge ───────────────────────────────────────────────────────────────

class StatusBadge extends StatelessWidget {
  final ScanStatus status;

  const StatusBadge({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    final (label, color, icon) = switch (status) {
      ScanStatus.idle      => ('READY',      AppTheme.textMuted,     Icons.radio_button_unchecked),
      ScanStatus.detecting => ('DETECTING',  AppTheme.accent,        Icons.search_rounded),
      ScanStatus.ocr       => ('READING',    AppTheme.warning,       Icons.text_fields_rounded),
      ScanStatus.ai        => ('ANALYZING',  AppTheme.accentWarm,    Icons.psychology_rounded),
      ScanStatus.done      => ('SOLVED',     AppTheme.correct,       Icons.check_circle_rounded),
      ScanStatus.error     => ('ERROR',      AppTheme.wrong,         Icons.error_rounded),
    };

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color:        color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border:       Border.all(color: color.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (status == ScanStatus.detecting || status == ScanStatus.ai ||
              status == ScanStatus.ocr)
            _PulsingDot(color: color)
          else
            Icon(icon, color: color, size: 12),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              fontFamily: 'JetBrainsMono',
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: color,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

class _PulsingDot extends StatefulWidget {
  final Color color;
  const _PulsingDot({required this.color});

  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double>   _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..repeat(reverse: true);
    _anim = Tween(begin: 0.3, end: 1.0).animate(_ctrl);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _anim,
    child: Container(
      width: 6, height: 6,
      decoration: BoxDecoration(
        color:  widget.color,
        shape:  BoxShape.circle,
      ),
    ),
  );
}

// ── Confidence bar ─────────────────────────────────────────────────────────────

class ConfidenceBar extends StatelessWidget {
  final double value; // 0.0 – 1.0
  const ConfidenceBar({super.key, required this.value});

  Color get _color {
    if (value >= 0.85) return AppTheme.correct;
    if (value >= 0.65) return AppTheme.warning;
    return AppTheme.wrong;
  }

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('CONFIDENCE',
            style: TextStyle(
              fontFamily: 'JetBrainsMono',
              fontSize: 10,
              color: AppTheme.textMuted,
              letterSpacing: 1,
            ),
          ),
          Text('${(value * 100).round()}%',
            style: TextStyle(
              fontFamily: 'JetBrainsMono',
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: _color,
            ),
          ),
        ],
      ),
      const SizedBox(height: 6),
      ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: LinearProgressIndicator(
          value: value,
          minHeight: 4,
          backgroundColor: AppTheme.surfaceBorder,
          valueColor: AlwaysStoppedAnimation(_color),
        ),
      ),
    ],
  );
}

// ── Provider chip ──────────────────────────────────────────────────────────────

class ProviderBadge extends StatelessWidget {
  final AiProvider provider;
  const ProviderBadge({super.key, required this.provider});

  Color get _color => switch (provider) {
    AiProvider.openai  => const Color(0xFF74AA9C),
    AiProvider.gemini  => const Color(0xFF4285F4),
    AiProvider.claude  => const Color(0xFFCC785C),
    AiProvider.offline => AppTheme.textMuted,
  };

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(
      color:        _color.withOpacity(0.15),
      borderRadius: BorderRadius.circular(6),
      border:       Border.all(color: _color.withOpacity(0.3)),
    ),
    child: Text(
      provider.shortName,
      style: TextStyle(
        fontFamily: 'JetBrainsMono',
        fontSize: 9,
        fontWeight: FontWeight.w700,
        color: _color,
        letterSpacing: 0.8,
      ),
    ),
  );
}
