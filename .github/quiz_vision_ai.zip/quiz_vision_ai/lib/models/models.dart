import 'package:flutter/foundation.dart';

// ── AI Provider enum ──────────────────────────────────────────────────────────
enum AiProvider { openai, gemini, claude, offline }

extension AiProviderX on AiProvider {
  String get displayName => switch (this) {
    AiProvider.openai  => 'OpenAI GPT-4',
    AiProvider.gemini  => 'Google Gemini',
    AiProvider.claude  => 'Anthropic Claude',
    AiProvider.offline => 'Offline Bank',
  };

  String get shortName => switch (this) {
    AiProvider.openai  => 'GPT',
    AiProvider.gemini  => 'GEMINI',
    AiProvider.claude  => 'CLAUDE',
    AiProvider.offline => 'LOCAL',
  };
}

// ── Detected MCQ ─────────────────────────────────────────────────────────────
@immutable
class McqQuestion {
  final String? questionNumber;
  final String  questionText;
  final String? optionA;
  final String? optionB;
  final String? optionC;
  final String? optionD;
  final String  rawText;

  const McqQuestion({
    this.questionNumber,
    required this.questionText,
    this.optionA,
    this.optionB,
    this.optionC,
    this.optionD,
    required this.rawText,
  });

  bool get hasOptions =>
      optionA != null || optionB != null ||
      optionC != null || optionD != null;

  String? optionText(String letter) => switch (letter.toUpperCase()) {
    'A' => optionA,
    'B' => optionB,
    'C' => optionC,
    'D' => optionD,
    _   => null,
  };

  /// Fingerprint to detect duplicate scans
  String get fingerprint {
    final q = questionText.replaceAll(RegExp(r'\s+'), ' ').trim();
    return q.length > 80 ? q.substring(0, 80) : q;
  }

  @override
  bool operator ==(Object other) =>
      other is McqQuestion && other.fingerprint == fingerprint;

  @override
  int get hashCode => fingerprint.hashCode;
}

// ── AI Answer ─────────────────────────────────────────────────────────────────
@immutable
class AiAnswer {
  final String  answer;        // 'A' | 'B' | 'C' | 'D'
  final double  confidence;    // 0.0 – 1.0
  final String? explanation;
  final AiProvider source;
  final bool    fromCache;

  const AiAnswer({
    required this.answer,
    required this.confidence,
    this.explanation,
    required this.source,
    this.fromCache = false,
  });

  int get confidencePct => (confidence * 100).round();

  AiAnswer copyWith({
    String? answer,
    double? confidence,
    String? explanation,
    AiProvider? source,
    bool? fromCache,
  }) => AiAnswer(
    answer:      answer      ?? this.answer,
    confidence:  confidence  ?? this.confidence,
    explanation: explanation ?? this.explanation,
    source:      source      ?? this.source,
    fromCache:   fromCache   ?? this.fromCache,
  );
}

// ── History Entry ─────────────────────────────────────────────────────────────
class HistoryEntry {
  final int?      id;
  final String    question;
  final String?   optionA;
  final String?   optionB;
  final String?   optionC;
  final String?   optionD;
  final String    answer;
  final double    confidence;
  final String?   explanation;
  final String    aiProvider;
  final DateTime  timestamp;
  final bool      bookmarked;

  const HistoryEntry({
    this.id,
    required this.question,
    this.optionA,
    this.optionB,
    this.optionC,
    this.optionD,
    required this.answer,
    required this.confidence,
    this.explanation,
    required this.aiProvider,
    required this.timestamp,
    this.bookmarked = false,
  });

  Map<String, dynamic> toMap() => {
    'question':    question,
    'option_a':    optionA,
    'option_b':    optionB,
    'option_c':    optionC,
    'option_d':    optionD,
    'answer':      answer,
    'confidence':  confidence,
    'explanation': explanation,
    'ai_provider': aiProvider,
    'timestamp':   timestamp.millisecondsSinceEpoch,
    'bookmarked':  bookmarked ? 1 : 0,
  };

  factory HistoryEntry.fromMap(Map<String, dynamic> m) => HistoryEntry(
    id:          m['id'] as int?,
    question:    m['question'] as String,
    optionA:     m['option_a'] as String?,
    optionB:     m['option_b'] as String?,
    optionC:     m['option_c'] as String?,
    optionD:     m['option_d'] as String?,
    answer:      m['answer']   as String,
    confidence:  (m['confidence'] as num).toDouble(),
    explanation: m['explanation'] as String?,
    aiProvider:  m['ai_provider'] as String,
    timestamp:   DateTime.fromMillisecondsSinceEpoch(m['timestamp'] as int),
    bookmarked:  (m['bookmarked'] as int) == 1,
  );

  HistoryEntry copyWith({bool? bookmarked}) => HistoryEntry(
    id:          id,
    question:    question,
    optionA:     optionA,
    optionB:     optionB,
    optionC:     optionC,
    optionD:     optionD,
    answer:      answer,
    confidence:  confidence,
    explanation: explanation,
    aiProvider:  aiProvider,
    timestamp:   timestamp,
    bookmarked:  bookmarked ?? this.bookmarked,
  );
}

// ── Scan State ────────────────────────────────────────────────────────────────
enum ScanStatus { idle, detecting, ocr, ai, done, error }

class ScanResult {
  final ScanStatus  status;
  final McqQuestion? question;
  final AiAnswer?    answer;
  final String?      errorMessage;
  final DateTime     updatedAt;

  ScanResult({
    required this.status,
    this.question,
    this.answer,
    this.errorMessage,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  ScanResult copyWith({
    ScanStatus? status,
    McqQuestion? question,
    AiAnswer? answer,
    String? errorMessage,
  }) => ScanResult(
    status:       status       ?? this.status,
    question:     question     ?? this.question,
    answer:       answer       ?? this.answer,
    errorMessage: errorMessage ?? this.errorMessage,
    updatedAt:    DateTime.now(),
  );
}

// ── App Settings ──────────────────────────────────────────────────────────────
class AppSettings {
  final AiProvider aiProvider;
  final Map<AiProvider, String> apiKeys;
  final bool speakAnswer;
  final bool autoScan;
  final bool offlineFirst;

  const AppSettings({
    this.aiProvider   = AiProvider.gemini,
    this.apiKeys      = const {},
    this.speakAnswer  = false,
    this.autoScan     = true,
    this.offlineFirst = false,
  });

  String? apiKeyFor(AiProvider p) => apiKeys[p];

  AppSettings copyWith({
    AiProvider? aiProvider,
    Map<AiProvider, String>? apiKeys,
    bool? speakAnswer,
    bool? autoScan,
    bool? offlineFirst,
  }) => AppSettings(
    aiProvider:   aiProvider   ?? this.aiProvider,
    apiKeys:      apiKeys      ?? this.apiKeys,
    speakAnswer:  speakAnswer  ?? this.speakAnswer,
    autoScan:     autoScan     ?? this.autoScan,
    offlineFirst: offlineFirst ?? this.offlineFirst,
  );
}
